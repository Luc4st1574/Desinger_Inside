"use client";

import React from "react";
import { KpiPoint } from "@/graphql/types/team";

type Props = {
  data: KpiPoint[] | undefined;
  loading?: boolean;
};

export default function KpiBarChart({ data, loading }: Props) {
  if (loading) {
    return <div className="h-36 bg-gray-50 rounded-md flex items-center justify-center text-gray-400">Loading chart...</div>;
  }

  return (
    <div className="h-36 bg-white border border-gray-200 rounded-md p-2">
      <div className="text-sm text-gray-500 mb-2">KPI Trend</div>
      <div className="flex items-end gap-2 h-24">
        {data?.map((point, idx) => (
          <div key={idx} className="flex-1">
            <div
              className="bg-blue-500 rounded-t-sm mx-auto"
              style={{ height: `${Math.max(4, point.value)}%`, width: '60%'}}
              title={`${point.label}: ${point.value}`}
            />
            <div className="text-xs text-gray-400 text-center mt-1">{point.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
