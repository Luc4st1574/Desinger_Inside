"use client";

import React from "react";

type Props = {
  title: string;
  value: string | number;
  sub?: string;
  loading?: boolean;
};

export default function MetricCard({ title, value, sub, loading }: Props) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <div className="text-sm text-gray-500">{title}</div>
      <div className="mt-2 text-2xl font-semibold text-gray-900">{loading ? '—' : value}</div>
      {sub && <div className="text-xs text-gray-400 mt-1">{sub}</div>}
    </div>
  );
}
