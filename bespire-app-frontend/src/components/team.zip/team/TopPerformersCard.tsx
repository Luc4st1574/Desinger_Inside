"use client";

import React from "react";
import { TopPerformer } from "@/graphql/types/team";

type Props = {
  title: string;
  items?: TopPerformer[];
  loading?: boolean;
};

export default function TopPerformersCard({ title, items, loading }: Props) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <div className="flex items-center justify-between">
        <div className="text-sm font-medium text-gray-700">{title}</div>
      </div>
      <div className="mt-3 space-y-2">
        {loading && <div className="text-gray-400">Loading...</div>}
        {!loading && items?.length === 0 && <div className="text-gray-400">No data</div>}
        {!loading && items?.map((it, i) => (
          <div key={it.id} className="flex items-center gap-3">
            <img src={it.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(it.name)}`} alt={it.name} className="w-10 h-10 rounded-full" />
            <div className="flex-1">
              <div className="text-sm font-medium text-gray-900">{i+1}. {it.name}</div>
              <div className="text-xs text-gray-500">{it.role}</div>
            </div>
            <div className="text-sm font-semibold text-gray-900">{it.kpi}%</div>
          </div>
        ))}
      </div>
    </div>
  );
}
