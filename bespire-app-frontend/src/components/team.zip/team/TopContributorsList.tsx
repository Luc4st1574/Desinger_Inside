"use client";

import React from "react";
import { TopPerformer } from "@/graphql/types/team";

type Props = {
  items?: TopPerformer[];
  loading?: boolean;
};

export default function TopContributorsList({ items, loading }: Props) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <div className="text-sm font-medium text-gray-700">Top Contributors</div>
      <div className="mt-3 space-y-2">
        {loading && <div className="text-gray-400">Loading...</div>}
        {!loading && items?.length === 0 && <div className="text-gray-400">No data</div>}
        {!loading && items?.map((it) => (
          <div key={it.id} className="flex items-center gap-3">
            <img src={it.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(it.name)}`} alt={it.name} className="w-8 h-8 rounded-full" />
            <div className="flex-1">
              <div className="text-sm text-gray-900">{it.name}</div>
              <div className="text-xs text-gray-500">{it.role}</div>
            </div>
            <div className="text-sm font-semibold text-gray-900">{it.kpi}%</div>
          </div>
        ))}
      </div>
    </div>
  );
}
