"use client";

import { useState, useMemo } from "react";
import TabSelector from "@/components/ui/TabSelector";
import MetricCard from "./MetricCard";
import KpiBarChart from "./KpiBarChart";
import TopPerformersCard from "./TopPerformersCard";
import TopContributorsList from "./TopContributorsList";
import { mockTeamOverview } from "@/mocks/team";
import People from "@/assets/icons/people.svg";
import Revision from "@/assets/icons/revision.svg";
import StarCircle from "@/assets/icons/star-circle.svg";
import Customize from "@/assets/icons/customize.svg";

type Props = {
  data?: any;
  loading?: boolean;
};

export default function OverviewMetricsComponent({ data, loading }: Props) {
  const [selectedPeriod, setSelectedPeriod] = useState("week");
  const periodItems = [
    { value: "day", label: "Day" },
    { value: "week", label: "Week" },
    { value: "month", label: "Month" },
    { value: "year", label: "Year" },
  ];

  const src = data ?? mockTeamOverview;

  const metricsData = useMemo(() => [
    {
      id: "avg-task",
      title: "Ave Task Completion",
      value: `${src.avgTaskCompletionDays} days`,
      sub: "Per task this week",
      icon: People,
      percent: "5.27%",
      trend: "up",
    },
    {
      id: "revision-rate",
      title: "Revision Rate",
      value: `${src.revisionRate} revisions`,
      sub: "Tasks required revisions",
      icon: Revision,
      percent: "8.35%",
      trend: "down",
    },
    {
      id: "overall-rating",
      title: "Overall Client Ratings",
      value: `${src.overallClientRating}/5 stars`,
      sub: `Across ${src.taskVolume ?? '-'} completed tasks`,
      icon: StarCircle,
      percent: "8.35%",
      trend: "down",
    },
    {
      id: "task-volume",
      title: "Task Volume",
      value: `${src.taskVolume} tasks`,
      sub: "Tasks completed this week",
      icon: Customize,
      percent: "18%",
      trend: "up",
    },
  ], [src]);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-medium text-gray-900">Overview Metrics</h2>
        <div className="flex space-x-2">
          <TabSelector items={periodItems} selectedValue={selectedPeriod} onChange={setSelectedPeriod} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        {metricsData.map((m) => (
          <div key={m.id} className="col-span-1">
            <MetricCard title={m.title} value={m.value} sub={m.sub} loading={loading} />
          </div>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-1 lg:grid-cols-[35%_1fr_320px] gap-4 items-start">
        <div>
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-gray-700">Average KPI Score</div>
              <div className="text-sm text-gray-500">View all →</div>
            </div>
            <div className="mt-3">
              <div className="text-3xl font-bold">98%</div>
              <div className="text-xs text-gray-400">compared last week</div>
            </div>
            <div className="mt-4">
              <KpiBarChart data={src.kpiTrend} loading={loading} />
            </div>
          </div>
        </div>

        <div>
          <div className="bg-green-50 rounded-lg p-4 border border-green-100">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-700">Top Performers</div>
                <div className="text-3xl font-bold">9 members</div>
                <div className="text-xs text-gray-500">compared last week</div>
              </div>
              <div className="text-sm text-green-600">18% ↑</div>
            </div>

            <div className="mt-4">
              <TopPerformersCard title="Top Performers" items={src.topPerformers} loading={loading} />
            </div>
          </div>
        </div>

        <div>
          <TopContributorsList items={src.topContributors} loading={loading} />
        </div>
      </div>
    </div>
  );
}
